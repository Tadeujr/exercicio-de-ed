#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "ordenada.h"

int main(){

	
	Lista* lista = criaLista(); 
	No *n = (No*) malloc(sizeof(No));
	

	push(lista,(int*)1);
	push(lista,(int*)122);
	push(lista,(int*)11);
	push(lista,(int*)445);


	
	imprimeLista(lista);
	printf("%d\n", min(lista,0)->data);
	printf("%d\n", max(lista,0)->data);
	//printf("%d\n",posicao(lista,4)->data);
	ordenaLista(lista);
	imprimeLista(lista);
	free(n);
	
	return 0;
}