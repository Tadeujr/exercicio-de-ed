#ifndef __ORDENADA_H__
#define __ORDENADA_H__

typedef struct no{
	void *data;
	struct no* proximo;
}No;

typedef struct lista{
	int tam;
	No* cabeca;
}Lista;

typedef struct no No;
typedef struct lista Lista;

No *criaNo(void * conteudo);
Lista * criaLista();
void push(Lista* lista,void * data);
bool vazia(Lista* lista);
void pop(Lista* lista);
No* posicao(Lista*lista, int indice);
int indiceNo(Lista*lista,No*no);
void removeno(Lista*lista,int indice);
void insereNo(Lista * lista, int indice, void * data);
void trocaNo(Lista*lista,No* noA, No*noB);
int tamLista(Lista * lista);
void imprimeLista(Lista* lista);
void destruirLista(Lista*lista);
No* min(Lista*lista, int indice);
No* max(Lista*lista, int indice);
void  ordenaLista(Lista*lista);

#endif